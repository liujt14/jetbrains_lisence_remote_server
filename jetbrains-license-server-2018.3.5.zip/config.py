#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    config.py
    ~~~~~~ on December 01,2017 11:16
    
    This is a configuration file.
    
    :license MIT, see LICENSE for more details.
    :copyright (c) 2013 - 2017 by laucyun<liu@liuker.xyz>.
"""
import os


class Config:
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    LOG_FILE_PATH = os.path.abspath(os.path.join(BASE_DIR, 'log', 'server.log'))
    ASNKEY = """
    -----BEGIN RSA PRIVATE KEY-----
    MIIBOgIBAAJBALecq3BwAI4YJZwhJ+snnDFj3lF3DMqNPorV6y5ZKXCiCMqj8OeOmxk4YZW9aaV9
    ckl/zlAOI0mpB3pDT+Xlj2sCAwEAAQJAW6/aVD05qbsZHMvZuS2Aa5FpNNj0BDlf38hOtkhDzz/h
    kYb+EBYLLvldhgsD0OvRNy8yhz7EjaUqLCB0juIN4QIhAOeCQp+NXxfBmfdG/S+XbRUAdv8iHBl+
    F6O2wr5fA2jzAiEAywlDfGIl6acnakPrmJE0IL8qvuO3FtsHBrpkUuOnXakCIQCqdr+XvADI/UTh
    TuQepuErFayJMBSAsNe3NFsw0cUxAQIgGA5n7ZPfdBi3BdM4VeJWb87WrLlkVxPqeDSbcGrCyMkC
    IFSs5JyXvFTreWt7IQjDssrKDRIPmALdNjvfETwlNJyY
    -----END RSA PRIVATE KEY-----
    """
    PCKS8KEY = """
    -----BEGIN PRIVATE KEY-----
    MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAt5yrcHAAjhglnCEn
    6yecMWPeUXcMyo0+itXrLlkpcKIIyqPw546bGThhlb1ppX1ySX/OUA4jSakHekNP
    5eWPawIDAQABAkBbr9pUPTmpuxkcy9m5LYBrkWk02PQEOV/fyE62SEPPP+GRhv4Q
    Fgsu+V2GCwPQ69E3LzKHPsSNpSosIHSO4g3hAiEA54JCn41fF8GZ90b9L5dtFQB2
    /yIcGX4Xo7bCvl8DaPMCIQDLCUN8YiXppydqQ+uYkTQgvyq+47cW2wcGumRS46dd
    qQIhAKp2v5e8AMj9ROFO5B6m4SsVrIkwFICw17c0WzDRxTEBAiAYDmftk990GLcF
    0zhV4lZvztasuWRXE+p4NJtwasLIyQIgVKzknJe8VOt5a3shCMOyysoNEg+YAt02
    O98RPCU0nJg=
    -----END PRIVATE KEY-----
    """


CONFIG = Config()
