This is a Python of JetBrains License Server emulator, supports python3 and python 2.7.

In March 5th, 2018: Support JetBrains 2017.3.3 and 2017.3.4

>
Instructions
------------
>
Install the required library (rsa and flask):
>
Use the `pip` command to install:
```
$ pip install rsa
$ pip install flask
```
>
Or
>
Through `requirements.txt` to install:
```
$ pip install -r requirements.txt
```
>
How to run?
----------
>
Use the `cd` command to switch to the directory where `server.py` resides, then:
>
Run:
```
$ python server.py
```
>
Run in the background:
```
$ nohup python server.py &
```

How to use?
----------
>
Locally built server address is `http://127.0.0.1:8000` or `http://0.0.0.0:8000`.
>
The detailed for activation steps, please read [http://jetbrains.license.laucyun.com/](http://jetbrains.license.laucyun.com/)