#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    RSAsign.py
    ~~~~~~ on December 01,2017 11:16

    RSA sign.

    :license MIT, see LICENSE for more details.
    :copyright (c) 2013 - 2017 by laucyun<liu@liuker.xyz>.
"""
from config import CONFIG
import rsa
import sys


def sign(signdata):
    if sys.version_info >= (3, 0):
        signature = py3sign(signdata)
    elif sys.version_info >= (2, 7):
        signature = py2sign(signdata)
    else:
        raise RuntimeError('At least Python 2.7 is required')
    return signature


def py2sign(signdata):
    if isinstance(signdata, unicode):
        signdata = signdata.encode("ascii")
    privkey = rsa.PrivateKey.load_pkcs1(CONFIG.ASNKEY)
    signature = rsa.sign(str.encode(signdata), privkey, 'MD5')
    signature = str_to_hex(signature)
    return signature


def py3sign(signdata):
    privkey = rsa.PrivateKey.load_pkcs1(CONFIG.ASNKEY)
    signature = rsa.sign(str.encode(signdata), privkey, 'MD5')
    signature = ByteToHex(signature)
    return signature


def ByteToHex(bins):
    return ''.join(["%02x" % x for x in bins]).strip()


def HexToByte(hexStr):
    return bytes.fromhex(hexStr)


def str_to_hex(s):
    return "".join("{:02x}".format(ord(c)) for c in s)


def hex_to_str(s):
    return ''.join([chr(i) for i in [int(b, 16) for b in s.split(' ')]])
