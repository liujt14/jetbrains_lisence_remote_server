#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    server.py
    ~~~~~~ on December 01,2017 11:16

    This is a web service.

    Update logs:
        In March 5th, 2018: Support JetBrains 2017.3.3 and 2017.3.4

    :license MIT, see LICENSE for more details.
    :copyright (c) 2013 - 2017 by laucyun<liu@liuker.xyz>.
"""
from flask import Flask
from flask import render_template
from flask import make_response
from flask import request
from config import CONFIG
import logging
import RSAsign as rsasign

app = Flask(
    __name__,
    template_folder=CONFIG.BASE_DIR
)

# log
logging.basicConfig(
    filename=CONFIG.LOG_FILE_PATH,
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/rpc/ping.action')
def ping():
    """
    request:
    /rpc/ping.action?buildNumber=2017.2.3+Build+PY-172.3968.37&clientVersion=4&hostName=2GIZRWS4YAICTHM&machineId=62dd416a-b26c-41ed-9888-18872b08c375&productCode=e8d15448-eecd-440e-bbe9-1e5f754d781b&productFamilyId=e8d15448-eecd-440e-bbe9-1e5f754d781b&salt=1512096608496&secure=false&ticketId=1&userName=Administrator

    :return:
            <!-- 7d4e2d3bf9a99030f9e76faab4949a090a37f943f974f3e0cf75a92b1c4013088ba969e24f801d31536a0ee7eed86ae551cc9e6540d4c122d48163d2d103ebb3 -->
            <PingResponse><message></message><responseCode>OK</responseCode><salt>1512096608496</salt></PingResponse>
    """
    try:
        salt = request.values.get("salt", "")

        if salt is None or salt == '':
            return 'error!'
        else:
            xml_content = '<PingResponse><message></message><responseCode>OK</responseCode><salt>' + salt + '</salt></PingResponse>'
            xml_signature = rsasign.sign(xml_content)
            body = '<!-- ' + xml_signature + ' -->\n' + xml_content
            resp = make_response(body, 200)
            resp.mimetype = "text/plain; charset=utf-8"
            return resp
    except Exception as e:
        print(e)
    return 'Ping!'


@app.route('/rpc/releaseTicket.action')
def release_ticket():
    """
    request:
    /rpc/releaseTicket.action?buildNumber=2017.2.3+Build+PY-172.3968.37&clientVersion=4&hostName=2GIZRWS4YAICTHM&machineId=62dd416a-b26c-41ed-9888-18872b08c375&productCode=e8d15448-eecd-440e-bbe9-1e5f754d781b&productFamilyId=e8d15448-eecd-440e-bbe9-1e5f754d781b&salt=1512096608496&secure=false&ticketId=1&userName=Administrator

    :return:
            <!-- 8a0bcd62b7f60fc1902aa567f9f938436a4e2dceff68198f39a50b5ebd41de446549a879324193a01119ba11ca989f946e93253f484cd2395659c2e62d8e2e01 -->
            <ReleaseTicketResponse><message></message><responseCode>OK</responseCode><salt>1512096608496</salt></ReleaseTicketResponse>
    """
    try:
        salt = request.values.get("salt", "")

        if salt is None or salt == "":
            return 'error!'
        else:
            xml_content = '<ReleaseTicketResponse><message></message><responseCode>OK</responseCode><salt>' + salt + '</salt></ReleaseTicketResponse>'
            xml_signature = rsasign.sign(xml_content)
            body = '<!-- ' + xml_signature + ' -->\n' + xml_content
            resp = make_response(body, 200)
            resp.mimetype = "text/plain; charset=utf-8"
            return resp
    except Exception as e:
        print(str(e))
    return 'releaseTicket!'


@app.route('/rpc/obtainTicket.action')
def obtain_ticket():
    """
    request:
    /rpc/obtainTicket.action?buildDate=20170726&buildNumber=2017.2.3+Build+PY-172.3968.37&clientVersion=4&hostName=localhost&machineId=62dd416a-b26c-41ed-9888-18872b08c375&productCode=e8d15448-eecd-440e-bbe9-1e5f754d781b&productFamilyId=e8d15448-eecd-440e-bbe9-1e5f754d781b&salt=1512096594559&secure=false&userName=Administrator&version=2017200&versionNumber=2017200
    /rpc/obtainTicket.action?buildDate=20171129&buildNumber=2017.3.4+Build+PS-173.4548.32&clientVersion=5&hostName=localhost&machineId=8d87fbb7-65f0-4ac0-9257-abc2c647318b&productCode=0d85f2cc-b84f-44c7-b319-93997d080ac9&productFamilyId=0d85f2cc-b84f-44c7-b319-93997d080ac9&salt=1520233451123&secure=false&userName=Administrator&version=2017300&versionNumber=2017300

    :return:
            <!-- 02e9a5502dd0f8fd555e957e271130bb4a1ed8ace741172209175821b52aada0fcb6e73908501ea031a2093eb7cc15434dfdc548763e55cb4df8efd4c1607cca -->
            <ObtainTicketResponse><message></message><prolongationPeriod>607875500</prolongationPeriod><responseCode>OK</responseCode><salt>1512096594559</salt><ticketId>1</ticketId><ticketProperties>licensee=Administrator	licenseType=0	</ticketProperties></ObtainTicketResponse>

            In 2017.3.4:
            <!-- 181aae076fcebc77406271fdd0aa6e97908be7443f6e3c5b1c3fba79d5b7f58fe030cbd885570532db82d5ebeb164af998580b174be1cca3f9f0392d1ca5599a -->
            <ObtainTicketResponse><message></message><prolongationPeriod>607875500</prolongationPeriod><responseCode>OK</responseCode><salt>1520233451123</salt><ticketId>1</ticketId><ticketProperties>licensee=Administrator	licenseType=0	</ticketProperties></ObtainTicketResponse>
    """
    try:
        salt = request.values.get("salt", "")
        username = request.values.get("userName", "")

        prolongation_period = "607875500"
        if salt is None or salt == "" or username is None or username == "":
            return 'error!'
        else:
            xml_content = '<ObtainTicketResponse><message></message><prolongationPeriod>' + prolongation_period + '</prolongationPeriod><responseCode>OK</responseCode><salt>' + salt + '</salt><ticketId>1</ticketId><ticketProperties>licensee=' + username + '\tlicenseType=0\t</ticketProperties></ObtainTicketResponse>'
            xml_signature = rsasign.sign(xml_content)
            body = '<!-- ' + xml_signature + ' -->\n' + xml_content
            resp = make_response(body, 200)
            resp.mimetype = "text/plain; charset=utf-8"
            return resp
    except Exception as e:
        print(str(e))
    return 'obtainTicket!'


if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8000)
